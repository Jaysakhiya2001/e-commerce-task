import { createSlice, createAsyncThunk, PayloadAction, AnyAction } from '@reduxjs/toolkit';
import api from '../../lib/axios';

export interface Product {
  id: string; // unique identifier
  name: string;
  price: number;
  description: string;
  category: Category;
  stock: number;
  image?: string;
}

export interface ProductListResponse {
  items: Product[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface Category {
  _id: string;
  name: string;
  description: string;
}

export interface CategoryListResponse {
  categories: Category[];
}

interface ProductState {
  items: Product[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  loading: boolean;
  error: string | null;

}

const initialState: ProductState = {
  items: [],
  total: 0,
  page: 1,
  limit: 9,
  totalPages: 0,
  loading: false,
  error: null,
};

export const fetchProducts = createAsyncThunk(
  'product/fetchProducts',
  async (
    { page = 1, limit = 9, search = '', category = [] }: { page?: number; limit?: number; search?: string; category?: string[] },
    { rejectWithValue }: { rejectWithValue: (value: any) => any }
  ) => {
    try {
      const response = await api.get<ProductListResponse>('/products', {
        params: {
          page,
          limit,
          search,
          ...(Array.isArray(category) && category.length ? { categories: category.join(',') } : {}),
        },
      });
      return response.data;
    } catch (err: any) {
      return rejectWithValue(err.response?.data?.message || 'Failed to fetch products');
    }
  }
);



const productSlice = createSlice({
  name: 'product',
  initialState,
  reducers: {},
  extraReducers: (builder: any) => {
    builder
      .addCase(fetchProducts.pending, (state: ProductState) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProducts.fulfilled, (state: ProductState, action: PayloadAction<ProductListResponse>) => {
        state.loading = false;
        state.items = action.payload.items;
        state.total = action.payload.total;
        state.page = action.payload.page;
        state.limit = action.payload.limit;
        state.totalPages = action.payload.totalPages;
        state.error = null;
      })
      .addCase(fetchProducts.rejected, (state: ProductState, action: AnyAction) => {
        state.loading = false;
        state.error = action.payload as string;
      })

  },
});

export default productSlice.reducer; 