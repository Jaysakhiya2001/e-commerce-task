import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { store } from "./lib/store";
import { ProductListPage } from "./screens/ProductListPage/ProductListPage";
import { Toaster } from "react-hot-toast";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <Provider store={store}>
      <ProductListPage />
      <Toaster position="top-right" reverseOrder={false} />
    </Provider>
  </StrictMode>,
);
