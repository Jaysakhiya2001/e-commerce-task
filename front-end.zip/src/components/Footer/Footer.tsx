import React from "react";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Separator } from "../ui/separator";
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react";

export const Footer = (): JSX.Element => {
  const linkSections = [
    {
      title: "Shop",
      links: [
        { name: "All Products", href: "#" },
        { name: "Headphones", href: "#" },
        { name: "Speakers", href: "#" },
        { name: "Accessories", href: "#" },
        { name: "New Arrivals", href: "#" },
      ],
    },
    {
      title: "Support",
      links: [
        { name: "Help Center", href: "#" },
        { name: "Contact Us", href: "#" },
        { name: "Size Guide", href: "#" },
        { name: "Shipping Info", href: "#" },
        { name: "Returns", href: "#" },
      ],
    },
    {
      title: "Company",
      links: [
        { name: "About Us", href: "#" },
        { name: "Careers", href: "#" },
        { name: "Press", href: "#" },
        { name: "Sustainability", href: "#" },
        { name: "Investors", href: "#" },
      ],
    },
  ];

  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
  ];

  return (
    <footer className="bg-gradient-to-br from-slate-50 to-gray-100 border-t border-gray-200">
      <div className="w-full px-4 sm:px-16 lg:px-20">
        {/* Main Footer Content */}
        <div className="py-12 sm:py-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
            {/* Brand Section - Full width on mobile, spans more columns on desktop */}
            <div className="sm:col-span-2 lg:col-span-5 xl:col-span-4">
              <div className="mb-6">
                <h2 className="text-2xl sm:text-3xl font-bold text-[#0c3356] mb-3 sm:mb-4">
                  FashionHub
                </h2>
                <p className="text-gray-600 text-sm sm:text-base leading-relaxed mb-4 sm:mb-6">
                  Discover premium audio experiences with our curated collection of 
                  headphones, speakers, and accessories. Quality sound for every lifestyle.
                </p>
              </div>

              {/* Contact Info - Optimized for mobile */}
              <div className="space-y-2 sm:space-y-3 mb-4 sm:mb-6">
                <div className="flex items-start text-gray-600">
                  <MapPin className="w-4 h-4 sm:w-5 sm:h-5 mr-2 sm:mr-3 text-[#3a4980] mt-0.5 flex-shrink-0" />
                  <span className="text-xs sm:text-sm leading-relaxed">
                    400 University Drive Suite 200, Coral Gables, FL 33134
                  </span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Phone className="w-4 h-4 sm:w-5 sm:h-5 mr-2 sm:mr-3 text-[#3a4980] flex-shrink-0" />
                  <span className="text-xs sm:text-sm">+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Mail className="w-4 h-4 sm:w-5 sm:h-5 mr-2 sm:mr-3 text-[#3a4980] flex-shrink-0" />
                  <span className="text-xs sm:text-sm">hello@fashionhub.com</span>
                </div>
              </div>

              {/* Social Links - Responsive sizing */}
              <div className="flex space-x-3 sm:space-x-4">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="w-8 h-8 sm:w-10 sm:h-10 bg-white rounded-full flex items-center justify-center text-gray-600 hover:text-[#3a4980] hover:bg-gray-50 transition-all duration-200 shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#3a4980] focus:ring-offset-2"
                  >
                    <social.icon className="w-4 h-4 sm:w-5 sm:h-5" />
                  </a>
                ))}
              </div>
            </div>

            {/* Navigation Links - Responsive grid */}
            <div className="sm:col-span-2 lg:col-span-5 xl:col-span-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
                {linkSections.map((section, index) => (
                  <div key={index} className="min-w-0">
                    <h3 className="font-semibold text-gray-900 text-base sm:text-lg mb-4 sm:mb-6">
                      {section.title}
                    </h3>
                    <nav className="space-y-3 sm:space-y-4">
                      {section.links.map((link, linkIndex) => (
                        <a
                          key={linkIndex}
                          href={link.href}
                          className="block text-gray-600 hover:text-[#3a4980] transition-colors duration-200 text-xs sm:text-sm focus:outline-none focus:text-[#3a4980] truncate"
                        >
                          {link.name}
                        </a>
                      ))}
                    </nav>
                  </div>
                ))}
              </div>
            </div>

            {/* Newsletter Section - Full width on mobile, proper column span on desktop */}
            <div className="sm:col-span-2 lg:col-span-2">
              <h3 className="font-semibold text-gray-900 text-base sm:text-lg mb-4 sm:mb-6">
                Stay Updated
              </h3>
              <p className="text-gray-600 text-xs sm:text-sm mb-4 sm:mb-6 leading-relaxed">
                Subscribe to get special offers, free giveaways, and updates.
              </p>
              
              <div className="space-y-3 sm:space-y-4">
                {/* Newsletter form - Stack on very small screens */}
                <div className="flex flex-col xs:flex-row gap-2">
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    className="flex-1 h-10 sm:h-12 border-gray-300 rounded-lg focus:border-[#3a4980] focus:ring-[#3a4980] text-sm"
                  />
                  <Button
                    size="sm"
                    className="h-10 sm:h-12 px-4 sm:px-6 bg-[#3a4980] hover:bg-[#2d3a6a] text-white rounded-lg whitespace-nowrap text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#3a4980] focus:ring-offset-2"
                  >
                    Subscribe
                  </Button>
                </div>
                <p className="text-xs text-gray-500 leading-relaxed">
                  By subscribing, you agree to our Privacy Policy and consent to receive updates.
                </p>
              </div>
            </div>
          </div>
        </div>

        <Separator className="bg-gray-300" />

        {/* Bottom Footer - Responsive layout */}
        <div className="py-6 sm:py-8">
          <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0 gap-4">
            <div className="text-xs sm:text-sm text-gray-600 text-center sm:text-left">
              © 2024 FashionHub. All rights reserved.
            </div>
            
            {/* Legal links - Responsive wrapping */}
            <div className="flex flex-wrap justify-center sm:justify-end items-center gap-4 sm:gap-6 text-xs sm:text-sm">
              <a 
                href="#" 
                className="text-gray-600 hover:text-[#3a4980] transition-colors focus:outline-none focus:text-[#3a4980] whitespace-nowrap"
              >
                Privacy Policy
              </a>
              <a 
                href="#" 
                className="text-gray-600 hover:text-[#3a4980] transition-colors focus:outline-none focus:text-[#3a4980] whitespace-nowrap"
              >
                Terms of Service
              </a>
              <a 
                href="#" 
                className="text-gray-600 hover:text-[#3a4980] transition-colors focus:outline-none focus:text-[#3a4980] whitespace-nowrap"
              >
                Cookie Policy
              </a>
              <a 
                href="#" 
                className="text-gray-600 hover:text-[#3a4980] transition-colors focus:outline-none focus:text-[#3a4980] whitespace-nowrap"
              >
                Accessibility
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};