import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import toast from "react-hot-toast";
import api from "../lib/axios";
import { X } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email("Invalid email format").min(1, "Email is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

interface LoginModalProps {
  open: boolean;
  onClose: () => void;
  onLoginSuccess?: (token: string) => void;
}

interface ApiErrorResponse {
  message: string;
  status: number;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  open,
  onClose,
  onLoginSuccess,
}) => {
  const [isLoading, setIsLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setError,
    reset,
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const handleLogin = async (data: LoginFormValues) => {
    try {
      setIsLoading(true);
      const response = await api.post<{ token: string }>("/auth/login", {
        email: data.email,
        password: data.password,
      });

      const { token } = response.data;
      localStorage.setItem("token", token);
      toast.success("Successfully logged in!");

      if (onLoginSuccess) {
        onLoginSuccess(token);
      }

      reset();
      onClose();
    } catch (error) {
      if (error && typeof error === 'object' && 'isAxiosError' in error) {
        const errorResponse = (error as any).response?.data as ApiErrorResponse | undefined;

        switch (errorResponse?.status) {
          case 404:
            setError("email", {
              type: "manual",
              message: "Email not registered",
            });
            toast.error("Email not found. Please check your email or register.");
            break;
          case 401:
            setError("password", {
              type: "manual",
              message: "Invalid password",
            });
            toast.error("Invalid password. Please try again.");
            break;
          default:
            toast.error(errorResponse?.message || "An error occurred during login");
        }
      } else {
        toast.error("Unable to connect to the server. Please try again later.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-[#f4e8f3] via-[#f3eff6] to-[#eee0f9] bg-opacity-90 backdrop-blur-sm px-2">
      <div className="absolute inset-0" onClick={onClose} />
      <Card className="relative z-10 w-full max-w-sm mx-auto shadow-2xl rounded-2xl border-0 animate-fade-in bg-white">
        <button
          className="absolute top-3 right-3 text-gray-400 hover:text-[#3a4980] transition-colors focus:outline-none"
          onClick={onClose}
          aria-label="Close login modal"
          type="button"
        >
          <X className="w-5 h-5" />
        </button>
        <CardHeader className="pb-2 text-center">
          <CardTitle className="text-[#3a4980] text-2xl font-bold">Sign in to your account</CardTitle>
          <div className="text-gray-500 text-sm mt-1">Welcome back! Please enter your details.</div>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={handleSubmit(handleLogin)}
            className="space-y-5 mt-2"
            autoComplete="off"
          >
            <div>
              <Input
                type="email"
                placeholder="Email address"
                {...register("email")}
                autoFocus
                disabled={isLoading}
                className={`rounded-lg px-4 py-2 border focus:ring-2 focus:ring-[#3a4980] focus:border-[#3a4980] ${errors.email ? "border-red-500 focus:ring-red-500" : "border-gray-300"}`}
              />
              {errors.email && (
                <div className="text-red-500 text-xs mt-1">
                  {errors.email.message}
                </div>
              )}
            </div>

            <div>
              <Input
                type="password"
                placeholder="Password"
                {...register("password")}
                disabled={isLoading}
                className={`rounded-lg px-4 py-2 border focus:ring-2 focus:ring-[#3a4980] focus:border-[#3a4980] ${errors.password ? "border-red-500 focus:ring-red-500" : "border-gray-300"}`}
              />
              {errors.password && (
                <div className="text-red-500 text-xs mt-1">
                  {errors.password.message}
                </div>
              )}
            </div>

            <Button
              type="submit"
              className="w-full bg-[#3a4980] hover:bg-[#2d3860] text-white font-semibold rounded-lg py-2 text-base shadow-md transition-colors"
              disabled={isLoading}
            >
              {isLoading ? "Logging in..." : "Login"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};