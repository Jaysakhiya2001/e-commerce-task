import React, { ChangeEvent, FC, useState } from 'react';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '../lib/store';
import { fetchProducts } from '../features/product/productSlice';
import { useDebounce } from '../hooks/useDebounce';
import { Input } from './ui/input';

export const SearchHeader: FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebounce(query, 400);

  React.useEffect(() => {
    dispatch(fetchProducts({ page: 1, limit: 9, search: debouncedQuery }));
  }, [debouncedQuery, dispatch]);

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setQuery(e.target.value);
  };

  return (
    <header className="w-full px-4 sm:px-10 lg:px-20 py-4 bg-white shadow-md">
      <div className="max-w-6xl mx-auto flex items-center gap-4">
        <h1 className="text-2xl font-bold text-[#3a4980] flex-shrink-0">Shop</h1>
        <Input
          placeholder="Search products..."
          value={query}
          onChange={handleChange}
          className="flex-1 max-w-lg focus-visible:ring-[#3a4980]"
        />
      </div>
    </header>
  );
};
