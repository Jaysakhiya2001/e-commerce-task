import { useState, useEffect } from "react";
import { Button } from "../../components/ui/button";
import { FilterSection } from "./sections/FilterSection/FilterSection";
import { HeroSection } from "./sections/HeroSection";
import { ProductGridSection } from "./sections/ProductGridSection";
import { Footer } from "../../components/Footer";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../../lib/store";
import { fetchProducts } from "../../features/product/productSlice";

export const ProductListPage = (): JSX.Element => {
  const dispatch = useDispatch<AppDispatch>();
  const { page, limit, totalPages } = useSelector((state: RootState) => state.product);
  useEffect(() => {
    dispatch(fetchProducts({ page, limit }));
  }, [dispatch, page, limit]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

  const handlePageChange = (newPage: number) => {
    dispatch(fetchProducts({ page: newPage, limit, category: selectedCategories }));
  };

  const handleCategoryChange = (categories: string[]) => {
    setSelectedCategories(categories);
    dispatch(fetchProducts({ page: 1, limit, category: categories }));
  };

  const handleClearAll = () => {
    setSelectedCategories([]);
    dispatch(fetchProducts({ page: 1, limit }));
  };

  return (
    <div className="bg-[#ffffff] flex flex-col min-h-screen w-full overflow-x-hidden">
            <div className="bg-[#ffffff] w-full relative">
        <div className="w-full">
          <HeroSection />

          <div className="w-full h-56 sm:h-64 md:h-72 lg:h-[400px] relative bg-[linear-gradient(42deg,rgba(244,232,243,1)_0%,rgba(243,239,246,1)_51%,rgba(238,224,249,1)_100%)] overflow-hidden flex items-center justify-center">
            <img
              className="absolute right-0 top-1/2 -translate-y-1/2 w-3/4 max-w-[600px] h-auto pointer-events-none object-contain"
              alt="Model background"
              src="public/img/model.png"
              loading="eager"
            />
            <div className="relative z-10 flex flex-col justify-center px-4 sm:px-6 lg:px-20 w-full">
              <div className="max-w-xs sm:max-w-md lg:max-w-lg">
                <h2 className="font-bold text-[#3a4980] text-xl sm:text-2xl md:text-3xl lg:text-[34px] leading-tight mb-4 sm:mb-6 lg:mb-8">
                  Grab Upto 50% Off On <br className="hidden sm:block" />
                  Selected Headphone
                </h2>
                <Button className="w-32 sm:w-36 lg:w-[136px] h-11 sm:h-12 lg:h-[49px] bg-[#3a4980] hover:bg-[#2d3a6a] rounded-full text-white font-semibold text-sm sm:text-base transition-all duration-200 hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-[#3a4980] focus:ring-offset-2 shadow-lg hover:shadow-xl">
                  Buy Now
                </Button>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:px-10 lg:px-20 sm:gap-0 mt-6 sm:mt-8 lg:mt-12">
            <div className="font-medium text-head-color text-xl sm:text-xl">Filters</div>

            <Button
              variant="outline"
              className="w-full sm:w-auto rounded-full border-[#e4e4e4] text-[#716c6c] text-sm font-normal hover:border-[#3a4980] hover:text-[#3a4980] transition-all duration-200 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-[#3a4980] focus:ring-offset-2"
              onClick={handleClearAll}
            >
              Clear All
            </Button>
          </div>

          <div className="flex flex-col lg:flex-row mt-6 sm:px-10 lg:px-20 gap-6 lg:gap-0 w-full">
            <div className="w-full lg:w-1/4">
              <FilterSection onCategoryChange={handleCategoryChange} selectedCategories={selectedCategories} />
            </div>
            <div className="w-full lg:w-3/4">
              <ProductGridSection />
              {totalPages > 1 && (
                <div className="flex justify-center mt-8">
                  <nav className="inline-flex -space-x-px">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                      <button
                        key={p}
                        className={`px-4 py-2 border border-gray-300 ${p === page ? 'bg-[#3a4980] text-white' : 'bg-white text-gray-700'} rounded mx-1`}
                        onClick={() => handlePageChange(p)}
                        disabled={p === page}
                      >
                        {p}
                      </button>
                    ))}
                  </nav>
                </div>
              )}
            </div>
          </div>

          <div className="mt-8">
            <Footer />
          </div>
        </div>
      </div>
    </div>
  );
};