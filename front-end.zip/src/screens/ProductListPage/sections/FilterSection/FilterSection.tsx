import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../../../../lib/store";
import { fetchCategories } from "../../../../features/category/categorySlice";

interface FilterSectionProps {
  onCategoryChange: (categories: string[]) => void;
  selectedCategories: string[];
}

export const FilterSection = ({ onCategoryChange, selectedCategories }: FilterSectionProps) => {
  const dispatch = useDispatch<AppDispatch>();
  const { items: rawCategories, loading: categoriesLoading, error: categoriesError } = useSelector((state: RootState) => state.category);
  const categories = Array.isArray(rawCategories) ? rawCategories : [];
  console.log({ categories });
  useEffect(() => {
    dispatch(fetchCategories());
  }, [dispatch]);

  const handleCheckboxChange = (categoryId: string) => {
    let newSelected: string[];
    if (selectedCategories.includes(categoryId)) {
      newSelected = selectedCategories.filter((c) => c !== categoryId);
    } else {
      newSelected = [...selectedCategories, categoryId];
    }
    onCategoryChange(newSelected);
  };

  return (
    <div>
      <div className="font-semibold mb-2">Categories</div>
      {categoriesLoading ? (
        <div>Loading categories...</div>
      ) : categoriesError ? (
        <div className="text-red-500">Categories not found.</div>
      ) : categories.length === 0 ? (
        <div>Categories not found.</div>
      ) : (
        <div className="flex flex-col gap-2">
          {categories.map((cat) => (
            <label key={cat._id} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={selectedCategories.includes(cat._id)}
                onChange={() => handleCheckboxChange(cat._id)}
              />
              {cat.name}
            </label>
          ))}
        </div>
      )}
    </div>
  );
}; 