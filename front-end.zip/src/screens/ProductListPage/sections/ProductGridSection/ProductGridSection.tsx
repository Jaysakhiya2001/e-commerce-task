import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../../../../lib/store";
import { addToCart } from "../../../../features/cart/cartSlice";
import { setUser } from "../../../../features/user/userSlice";
import { LoginModal } from "../../../../components/LoginModal";
import { useState } from "react";

export const ProductGridSection = () => {
  const dispatch = useDispatch<AppDispatch>();
  const {
    items = [],
    loading,
    error,
  } = useSelector((state: RootState) => state.product || {});
  const { user } = useSelector((state: RootState) => state.user || {});
  const cartLoading = useSelector((state: RootState) => (state.cart ? state.cart.loading : false));
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [loginError, setLoginError] = useState("");

  if (loading) return <div className="p-8 text-center">Loading products...</div>;
  if (error) return <div className="p-8 text-center text-red-500">Product not found.</div>;
  if (!Array.isArray(items) || !items.length) return <div className="p-8 text-center">Product not found.</div>;

  const handleAddToCart = (product: any) => {
    if (!user) {
      setLoginModalOpen(true);
    } else {
      dispatch(addToCart(product));
    }
  };

  const handleLoginSuccess = (token: string) => {
    dispatch(setUser({ token }));
    setLoginModalOpen(false);
    setLoginError("");
  };

  return (
    <>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 gap-4">
        {Array.isArray(items) && items.map((product, idx) => (
          <div key={idx} className="border rounded-lg p-4 flex flex-col items-center">
            <img
              src={`public/img/product.png`}
              alt={product.name}
              className="w-24 h-24 object-contain mb-2 rounded"
              loading="lazy"
            />
            <div className="font-semibold text-center">{product.name}</div>
            <div className="text-[#3a4980] font-bold mt-1">${product.price}</div>
            <div className="text-xs text-gray-500 mt-1">{product.description}</div>
            <div className="text-xs text-gray-700 mt-1">Category: {product.category?.name ?? ''}</div>
            <div className="text-xs text-gray-700 mt-1">Stock: {product.stock}</div>
            <button
              className="mt-3 px-4 py-2 bg-[#3a4980] text-white rounded hover:bg-[#2d3a6a] disabled:opacity-60"
              onClick={() => handleAddToCart(product)}
              disabled={cartLoading}
            >
              {cartLoading ? "Adding..." : "Add to Cart"}
            </button>
          </div>
        ))}
      </div>
      <LoginModal
        open={loginModalOpen && !user}
        onClose={() => setLoginModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </>
  );
};