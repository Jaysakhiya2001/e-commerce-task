import { BellIcon, SearchIcon, MenuIcon, X, ChevronDown, LogOut } from "lucide-react";
import { useRef, useState, useEffect } from "react";
import { Input } from "../../../../components/ui/input";
import { useDebounce } from "../../../../hooks/useDebounce";
import { fetchProducts } from "../../../../features/product/productSlice";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "../../../../components/ui/avatar";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../../../../lib/store";
import { logout, setUser } from "../../../../features/user/userSlice";
import { LoginModal } from "../../../../components/LoginModal";

export const HeroSection = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const debouncedQuery = useDebounce(searchQuery, 400);
  const searchRef = useRef<HTMLDivElement>(null);

  const dispatch = useDispatch<AppDispatch>();
  const { user } = useSelector((state: RootState) => state.user);

  // Navigation menu items with icons and descriptions
  const navItems = [
    {
      label: "Category",
      href: "#",
      description: "Browse all categories",
      hasSubmenu: true,
      submenu: ["Electronics", "Fashion", "Sports", "Home & Garden"]
    },
    {
      label: "Brand",
      href: "#",
      description: "Explore top brands",
      hasSubmenu: true,
      submenu: ["Nike", "Adidas", "Apple", "Samsung"]
    },
    {
      label: "Contact",
      href: "#",
      description: "Get in touch with us",
      hasSubmenu: false
    },
    {
      label: "FAQ's",
      href: "#",
      description: "Frequently asked questions",
      hasSubmenu: false
    },
  ];

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (isSearchOpen && searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isSearchOpen]);

  useEffect(() => {
    if (debouncedQuery.trim() !== '' || isSearchOpen === false) { // fetch when query nonempty
      dispatch(fetchProducts({ page: 1, limit: 9, search: debouncedQuery }))
    }
  }, [debouncedQuery, dispatch]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) setIsMobileMenuOpen(false);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleLogout = () => {
    dispatch(logout());
    setIsUserMenuOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-50 flex items-center justify-between w-full px-2 sm:px-4 lg:px-20 py-3 sm:py-4 lg:py-5 border-b border-[#ececec] bg-white/95 backdrop-blur-md shadow-sm">
        <div className="flex items-center gap-2 sm:gap-6 lg:gap-[60px] min-w-0">
          {/* Logo */}
          <h1 className="font-extrabold text-lg sm:text-xl lg:text-[32.8px] text-[#0c3356] truncate flex-shrink-0">
            FashionHub
          </h1>
          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-start gap-[32px] xl:gap-[50px]">
            {navItems.map((item, index) => (
              <div key={index} className="relative group">
                <a
                  href={item.href}
                  className="font-medium text-base text-[#1d364d] whitespace-nowrap hover:text-[#3a4980] transition-colors focus:outline-none focus:text-[#3a4980] flex items-center gap-1"
                >
                  {item.label}
                  {item.hasSubmenu && <ChevronDown className="w-4 h-4" />}
                </a>

                {/* Desktop Dropdown */}
                {item.hasSubmenu && (
                  <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                    <div className="py-2">
                      {item.submenu?.map((subItem, subIndex) => (
                        <a
                          key={subIndex}
                          href="#"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#3a4980] transition-colors"
                        >
                          {subItem}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-1 sm:gap-3 lg:gap-[17px] min-w-0">
          {/* Search Button */}
          <button
            className="w-8 h-8 sm:w-9 sm:h-9 lg:w-[44px] lg:h-[44px] bg-[#eeeff8] rounded-full flex items-center justify-center hover:bg-[#e1e3f0] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#3a4980] focus:ring-offset-2"
            aria-label="Search"
            onClick={() => { setIsSearchOpen(prev => !prev); setSearchQuery(''); }}
          >
            <SearchIcon className="w-4 h-4 lg:w-5 lg:h-5" />
          </button>
          {/* Search Input */}
          {isSearchOpen && (
            <div ref={searchRef} className="relative">
              <Input
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="w-40 sm:w-60 lg:w-72 ml-2 transition-all"
              />
            </div>
          )}
          {/* Notification Bell */}
          <div className="relative">
            <button
              className="w-8 h-8 sm:w-9 sm:h-9 lg:w-[44px] lg:h-[44px] bg-[#f5f1ee] rounded-full flex items-center justify-center hover:bg-[#ede8e5] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#3a4980] focus:ring-offset-2"
              aria-label="Notifications"
            >
              <BellIcon className="w-4 h-4 lg:w-[21px] lg:h-[21px]" />
            </button>
            <Badge className="absolute w-2 h-2 sm:w-2.5 sm:h-2.5 -top-0.5 -right-0.5 p-0 bg-[#d75951] border-2 border-white animate-pulse" />
          </div>
          {/* User Profile or Login Button */}
          {user ? (
            <div className="hidden sm:flex items-center gap-2 lg:gap-3.5 user-menu-container relative min-w-0">
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center gap-2 lg:gap-3.5 hover:bg-gray-50 rounded-lg p-1 transition-colors focus:outline-none focus:ring-2 focus:ring-[#3a4980] focus:ring-offset-2"
                aria-label="User menu"
              >
                <Avatar className="w-8 h-8 sm:w-9 sm:h-9 lg:w-[44px] lg:h-[44px] ring-2 ring-transparent hover:ring-[#3a4980] transition-all">
                  <AvatarImage src="/rectangle-1.png" alt="User profile" />
                  <AvatarFallback className="text-xs sm:text-sm bg-[#3a4980] text-white">{user.username.slice(0, 2).toUpperCase() || "U"}</AvatarFallback>
                </Avatar>
                <div className="hidden md:flex flex-col items-start gap-1 lg:gap-[7px] min-w-0">
                  <span className="font-medium text-xs text-[#c0c3c6] truncate">
                    Welcome!
                  </span>
                  <span className="font-semibold text-sm lg:text-base text-[#1d364d] whitespace-nowrap truncate">
                    {user.username}
                  </span>
                </div>
                <ChevronDown className="w-4 h-4 text-gray-400 hidden md:block" />
              </button>
              {/* User Dropdown Menu */}
              {isUserMenuOpen && (
                <div className="absolute top-full right-0 mt-2 w-44 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                  <div className="py-2">
                    <button
                      className="flex items-center gap-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#3a4980] transition-colors w-full text-left"
                      onClick={handleLogout}
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <Button
              className="ml-2"
              onClick={() => setIsLoginModalOpen(true)}
            >
              Login
            </Button>
          )}
          {/* Mobile Menu Button */}
          <div className="mobile-menu-container lg:hidden">
            <Button
              variant="ghost"
              size="sm"
              className="w-8 h-8 sm:w-9 sm:h-9 p-0 hover:bg-gray-100 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#3a4980] focus:ring-offset-2"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle menu"
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5 text-gray-700" />
              ) : (
                <MenuIcon className="w-5 h-5 text-gray-700" />
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Login Modal */}
      <LoginModal
        open={isLoginModalOpen && !user}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={(token: string) => { dispatch(setUser({ token })); }}
      />

      {/* Enhanced Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setIsMobileMenuOpen(false)}
          />
          {/* Mobile Menu Panel */}
          <div className="fixed top-0 right-0 h-full w-80 max-w-[90vw] bg-white shadow-2xl transform transition-transform duration-300 ease-out mobile-menu-container flex flex-col">
            {/* Mobile Menu Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-[#0c3356]">Menu</h2>
              <Button
                variant="ghost"
                size="sm"
                className="w-8 h-8 p-0"
                onClick={() => setIsMobileMenuOpen(false)}
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            {/* User Profile Section - Mobile */}
            <div className="p-4 border-b border-gray-100 bg-gradient-to-r from-[#f8f9ff] to-[#f0f2ff]">
              {user ? (
                <div className="flex items-center gap-3">
                  <Avatar className="w-12 h-12 ring-2 ring-[#3a4980]/20">
                    <AvatarImage src="/rectangle-1.png" alt="User profile" />
                    <AvatarFallback className="bg-[#3a4980] text-white">{user.username.slice(0, 2).toUpperCase() || "U"}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold text-[#1d364d] truncate">{user.username}</p>
                    <p className="text-sm text-[#c0c3c6]">Welcome!</p>
                  </div>
                </div>
              ) : (
                <Button className="w-full mt-2" onClick={() => { setIsLoginModalOpen(true); setIsMobileMenuOpen(false); }}>Login</Button>
              )}
            </div>
            {/* Navigation Links */}
            <nav className="flex-1 overflow-y-auto">
              <div className="p-4 space-y-2">
                {navItems.map((item, index) => (
                  <div key={index} className="space-y-2">
                    <a
                      href={item.href}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors group"
                      onClick={() => !item.hasSubmenu && setIsMobileMenuOpen(false)}
                    >
                      <div>
                        <div className="font-medium text-[#1d364d] group-hover:text-[#3a4980] transition-colors">
                          {item.label}
                        </div>
                        <div className="text-sm text-gray-500 mt-0.5">
                          {item.description}
                        </div>
                      </div>
                      {item.hasSubmenu && (
                        <ChevronDown className="w-4 h-4 text-gray-400" />
                      )}
                    </a>
                    {/* Mobile Submenu */}
                    {item.hasSubmenu && (
                      <div className="ml-4 space-y-1">
                        {item.submenu?.map((subItem, subIndex) => (
                          <a
                            key={subIndex}
                            href="#"
                            className="block p-2 text-sm text-gray-600 hover:text-[#3a4980] hover:bg-gray-50 rounded transition-colors"
                            onClick={() => setIsMobileMenuOpen(false)}
                          >
                            {subItem}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
              {/* User Actions - Mobile */}
              {user && (
                <div className="border-t border-gray-200 p-4 space-y-2">
                  <button
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors text-gray-700 hover:text-[#3a4980] w-full text-left"
                    onClick={handleLogout}
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="font-medium">Sign Out</span>
                  </button>
                </div>
              )}
            </nav>
          </div>
        </div>
      )}
    </>
  );
};