import { Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { InjectModel } from '@nestjs/mongoose';
import { User, UserDocument } from './user.schema';
import { Model } from 'mongoose';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(@InjectModel(User.name) private userModel: Model<UserDocument>) {}

  async create(dto: CreateUserDto) {
    const hashed = await bcrypt.hash(dto.password, 10);
    return this.userModel.create({
      userName: dto.userName,
      email: dto.email,
      password: hashed,
      role: dto.role || 'end-user',
    });
  }

  async findByEmail(email: string) {
    return this.userModel.findOne({ email });
  }
}
