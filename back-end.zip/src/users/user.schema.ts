import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Role } from '../common';

@Schema({ timestamps: true })
export class User {
  @Prop({ required: true })
  public userName: string;

  @Prop({ required: true, unique: true })
  public email: string;

  @Prop({ required: true })
  public password: string;

  @Prop({ enum: Role, default: Role.END_USER })
  public role: Role;
}

export type UserDocument = User & Document;
export const UserSchema = SchemaFactory.createForClass(User);
