export enum Role {
    ADMIN = "admin",
    END_USER = "end-user"
}