import mongoose from 'mongoose';
import { Logger } from '@nestjs/common';

export function setupMongooseConnectionLogger() {
  const logger = new Logger('MongooseConnection');
  mongoose.connection.on('connected', () => {
    logger.log('Database connection established');
  });
  mongoose.connection.on('error', (err) => {
    logger.error('Database connection error: ' + err);
  });
  mongoose.connection.on('disconnected', () => {
    logger.warn('Database connection lost');
  });
}
