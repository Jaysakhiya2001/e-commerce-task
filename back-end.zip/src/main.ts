import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe, Logger } from '@nestjs/common';
import { setupMongooseConnectionLogger } from './common/db-connection';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const logger = new Logger('Bootstrap');
  try {
    // Database connection events
    setupMongooseConnectionLogger();

    const app = await NestFactory.create(AppModule, { logger: ['log', 'error', 'warn', 'debug', 'verbose'] });
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }));
    app.enableCors();
    app.setGlobalPrefix('api');

    // Swagger setup
    const config = new DocumentBuilder()
      .setTitle('E-Commerce API')
      .setDescription('API documentation for the E-Commerce backend')
      .setVersion('1.0')
      .addBearerAuth()
      .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('api', app, document);

    process.on('unhandledRejection', (reason, promise) => {
      logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
    });
    process.on('uncaughtException', (err) => {
      logger.error('Uncaught Exception thrown:', err);
      process.exit(1);
    });

    await app.listen(5000);
    logger.log('Server started on http://localhost:5000');
    logger.log('Swagger API docs available at http://localhost:5000/api');
  } catch (error) {
    Logger.error('Failed to bootstrap application: ' + error.message);
    process.exit(1);
  }
}
bootstrap();
