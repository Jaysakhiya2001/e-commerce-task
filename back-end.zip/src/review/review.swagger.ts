import { ApiBody, ApiOperation, ApiParam, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { CreateReviewDto } from './dto/create-review.dto';
import { UpdateReviewDto } from './dto/update-review.dto';

export const ReviewSwaggerDocs = {
  create: [
    ApiBearerAuth(),
    ApiOperation({ summary: 'Create a new review (protected)' }),
    ApiBody({ type: CreateReviewDto }),
    ApiResponse({ status: 201, description: 'Review created successfully' })
  ],
  findAll: [
    ApiOperation({ summary: 'Get all reviews (optionally filter by product)' }),
    ApiResponse({ status: 200, description: 'List of reviews' })
  ],
  findById: [
    ApiOperation({ summary: 'Get review by ID' }),
    ApiParam({ name: 'id', type: String }),
    ApiResponse({ status: 200, description: 'Review found' })
  ],
  update: [
    ApiBearerAuth(),
    ApiOperation({ summary: 'Update a review (protected)' }),
    ApiParam({ name: 'id', type: String }),
    ApiBody({ type: UpdateReviewDto }),
    ApiResponse({ status: 200, description: 'Review updated successfully' })
  ],
  delete: [
    ApiBearerAuth(),
    ApiOperation({ summary: 'Delete a review (protected)' }),
    ApiParam({ name: 'id', type: String }),
    ApiResponse({ status: 200, description: 'Review deleted successfully' })
  ]
};
