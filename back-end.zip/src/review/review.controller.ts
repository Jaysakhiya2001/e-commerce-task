import { Controller, Post, Get, Put, Delete, Body, Param, Query, UseGuards, Req, BadRequestException, InternalServerErrorException } from '@nestjs/common';
import { ReviewService } from './review.service';
import { Review } from './review.schema';
import { CreateReviewDto } from './dto/create-review.dto';
import { UpdateReviewDto } from './dto/update-review.dto';
import { JwtAuthGuard } from '../auth/guard';
import { Types } from 'mongoose';

@Controller('reviews')
export class ReviewController {
  constructor(private readonly reviewService: ReviewService) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  async create(@Body() dto: CreateReviewDto, @Req() req) {
    if (!dto.user && req.user) {
      dto.user = req.user.sub;
    }
    if (!Types.ObjectId.isValid(dto.product) || !Types.ObjectId.isValid(dto.user)) {
      throw new BadRequestException('Invalid product or user ID');
    }
    const data = {
      ...dto,
      product: new Types.ObjectId(dto.product),
      user: new Types.ObjectId(dto.user),
    };
    try {
      const review = await this.reviewService.create(data);
      return { message: 'Review created successfully', review };
    } catch (error) {
      throw new InternalServerErrorException('Failed to create review: ' + error.message);
    }
  }

  @Get()
  async findAll(@Query('productId') productId?: string) {
    try {
      const reviews = await this.reviewService.findAll(productId);
      return { message: 'Reviews fetched successfully', reviews };
    } catch (error) {
      throw new InternalServerErrorException('Failed to fetch reviews: ' + error.message);
    }
  }

  @Get(':id')
  async findById(@Param('id') id: string) {
    if (!Types.ObjectId.isValid(id)) {
      throw new BadRequestException('Invalid review ID');
    }
    try {
      const review = await this.reviewService.findById(id);
      if (!review) throw new BadRequestException('Review not found');
      return { message: 'Review fetched successfully', review };
    } catch (error) {
      throw new InternalServerErrorException('Failed to fetch review: ' + error.message);
    }
  }

  @UseGuards(JwtAuthGuard)
  @Put(':id')
  async update(@Param('id') id: string, @Body() dto: UpdateReviewDto) {
    if (!Types.ObjectId.isValid(id)) {
      throw new BadRequestException('Invalid review ID');
    }
    try {
      const review = await this.reviewService.update(id, dto);
      if (!review) throw new BadRequestException('Review not found');
      return { message: 'Review updated successfully', review };
    } catch (error) {
      throw new InternalServerErrorException('Failed to update review: ' + error.message);
    }
  }

  @Delete(':id')
  async delete(@Param('id') id: string) {
    if (!Types.ObjectId.isValid(id)) {
      throw new BadRequestException('Invalid review ID');
    }
    try {
      const result = await this.reviewService.delete(id);
      if (!result) throw new BadRequestException('Review not found');
      return { message: 'Review deleted successfully' };
    } catch (error) {
      throw new InternalServerErrorException('Failed to delete review: ' + error.message);
    }
  }
}
