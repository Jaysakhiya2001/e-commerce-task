import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Review } from './review.schema';

@Injectable()
export class ReviewService {
  constructor(@InjectModel(Review.name) private reviewModel: Model<Review>) {}

  async create(data: Partial<Review>) {
    // Convert string IDs to ObjectId if needed
    if (data.product && typeof data.product === 'string') {
      data.product = (this.reviewModel.db as any).mongoose.Types.ObjectId(data.product);
    }
    if (data.user && typeof data.user === 'string') {
      data.user = (this.reviewModel.db as any).mongoose.Types.ObjectId(data.user);
    }
    return this.reviewModel.create(data);
  }

  async findAll(productId?: string) {
    const filter = productId ? { product: productId } : {};
    return this.reviewModel.find(filter).populate('user').populate('product').exec();
  }

  async findById(id: string) {
    return this.reviewModel.findById(id).populate('user').populate('product').exec();
  }

  async update(id: string, data: Partial<Review>) {
    return this.reviewModel.findByIdAndUpdate(id, data, { new: true }).exec();
  }

  async delete(id: string) {
    return this.reviewModel.findByIdAndDelete(id).exec();
  }
}
