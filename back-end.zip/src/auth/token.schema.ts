import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Types } from "mongoose";

@Schema({ timestamps: true })
export class Token {
    @Prop({ required: true, unique: true })
    private token: string;

    @Prop({ type: Types.ObjectId, ref: "User" })
    private userId: Types.ObjectId;

    @Prop({ default: false })
    private isRevoked: boolean;

    @Prop({ default: () => new Date(Date.now() + 86400000) })
    private expiresAt: Date;
}

export type TokenDocument = Token & Document;

export const TokenSchema = SchemaFactory.createForClass(Token);