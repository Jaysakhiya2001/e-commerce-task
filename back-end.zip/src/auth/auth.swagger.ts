import { ApiBody, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';

export const AuthSwaggerDocs = {
  register: [
    ApiOperation({ summary: 'Register a new user' }),
    ApiBody({ type: RegisterDto }),
    ApiResponse({ status: 201, description: 'User registered successfully' })
  ],
  login: [
    ApiOperation({ summary: 'Login a user' }),
    ApiBody({ type: LoginDto }),
    ApiResponse({ status: 200, description: 'User logged in successfully' })
  ],
  logout: [
    ApiOperation({ summary: 'Logout a user' }),
    ApiResponse({ status: 200, description: 'User logged out successfully' })
  ]
};
