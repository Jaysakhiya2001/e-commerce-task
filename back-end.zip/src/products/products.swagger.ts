import { ApiBody, ApiOperation, ApiParam, ApiQuery, ApiResponse } from '@nestjs/swagger';
import { CreateProductDto } from './dto/create-product.dto';

export const ProductSwaggerDocs = {
  create: [
    ApiOperation({ summary: 'Create a new product' }),
    ApiBody({ type: CreateProductDto }),
    ApiResponse({ status: 201, description: 'Product created successfully' })
  ],
  findAll: [
    ApiOperation({ summary: 'Get paginated list of products' }),
    ApiQuery({ name: 'page', required: false, type: Number }),
    ApiQuery({ name: 'limit', required: false, type: Number }),
    ApiQuery({ name: 'search', required: false, type: String }),
    ApiQuery({ name: 'category', required: false, type: String }),
    ApiResponse({ status: 200, description: 'Paginated product list' })
  ],
  findById: [
    ApiOperation({ summary: 'Get product by ID' }),
    ApiParam({ name: 'id', type: String }),
    ApiResponse({ status: 200, description: 'Product found' })
  ]
};
