import { IsNotEmpty, IsString, IsNumber, IsMongoId, Min, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateProductDto {
  @ApiProperty({ example: 'iPhone 15', description: 'Product name' })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({ example: 999.99, description: 'Product price' })
  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  price: number;

  @ApiProperty({ example: 'Latest Apple iPhone', description: 'Product description' })
  @IsNotEmpty()
  @IsString()
  description: string;

  @ApiProperty({ example: '60f7c2b8e1d2c8a1b8e1d2c8', description: 'Category ID' })
  @IsNotEmpty()
  @IsMongoId()
  category: string;

  @ApiProperty({ example: 10, description: 'Stock quantity', required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  stock?: number;
}
