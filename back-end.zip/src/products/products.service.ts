import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Product } from './product.schema';

@Injectable()
export class ProductsService {
  constructor(@InjectModel(Product.name) private productModel: Model<Product>) { }

  async create(data: Partial<Product>): Promise<Product> {
    return this.productModel.create(data);
  }


  async findPaginated({
    page = 1,
    limit = 10,
    search = '',
    categories = ''
  }: {
    page?: number;
    limit?: number;
    search?: string;
    categories?: string | string[];
  }) {
    const filter: any = {};
    if (search) {
      filter.name = { $regex: search, $options: 'i' };
    }
    if (categories) {
      let categoryArr: string[] = [];
      if (Array.isArray(categories)) {
        categoryArr = categories;
      } else if (typeof categories === 'string') {
        categoryArr = categories.split(',').map((c) => c.trim()).filter(Boolean);
      }
      if (categoryArr.length > 0) {
        filter.category = { $in: categoryArr };
      }
    }
    const skip = (page - 1) * limit;
    const [items, total] = await Promise.all([
      this.productModel.find(filter).populate('category').skip(skip).limit(limit).exec(),
      this.productModel.countDocuments(filter)
    ]);
    return {
      items,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    };
  }

  async findById(id: string): Promise<Product> {
    return this.productModel.findById(id).populate('category').exec();
  }
}
