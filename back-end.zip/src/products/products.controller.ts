import { Controller, Get, Post, Body, Param, Query, UsePipes, ValidationPipe } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBody, ApiResponse, ApiQuery, ApiParam } from '@nestjs/swagger';
import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';

@ApiTags('Products')
@Controller('products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) { }

  @Post()
  @ApiOperation({ summary: 'Create a new product' })
  @ApiBody({ type: CreateProductDto })
  @ApiResponse({ status: 201, description: 'Product created successfully' })
  @UsePipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))
  async create(@Body() body: CreateProductDto) {
    return this.productsService.create(body);
  }


  @Get()
  @ApiOperation({ summary: 'Get paginated list of products' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiQuery({ name: 'categories', required: false, type: String, description: 'Comma separated category ids' })
  @ApiResponse({ status: 200, description: 'Paginated product list' })
  async findAll(@Query() query: Record<string, string>) {
    const { page = '1', limit = '9', search, categories } = query;
    const params: any = {
      page: parseInt(page),
      limit: parseInt(limit),
    };
    if (search) params.search = search;
    if (categories) params.categories = categories;
    return this.productsService.findPaginated(params);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get product by ID' })
  @ApiParam({ name: 'id', type: String })
  @ApiResponse({ status: 200, description: 'Product found' })
  async findById(@Param('id') id: string) {
    return this.productsService.findById(id);
  }
}
