import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { getModelToken } from '@nestjs/mongoose';
import { faker } from '@faker-js/faker';

async function bootstrap() {
  console.log('Seeder started...');
  try {
    const app = await NestFactory.createApplicationContext(AppModule);
    const CategoryModel = app.get(getModelToken('Category'));
    const ProductModel = app.get(getModelToken('Product'));
    const UserModel = app.get(getModelToken('User'));

    // Seed categories
    const categories = [];
    for (let i = 0; i < 5; i++) {
      const category = await CategoryModel.create({
        name: faker.commerce.department() + '_' + faker.string.uuid().slice(0, 4),
        description: faker.commerce.productDescription(),
      });
      categories.push(category);
    }

    // Seed users
    const users = [];
    for (let i = 0; i < 5; i++) {
      const user = await UserModel.create({
        userName: faker.person.fullName(),
        email: faker.internet.email(),
        password: faker.internet.password(),
        role: i === 0 ? 'admin' : 'end-user',
      });
      users.push(user);
    }

    // Seed products
    for (let i = 0; i < 20; i++) {
      await ProductModel.create({
        name: faker.commerce.productName(),
        price: faker.number.float({ min: 10, max: 1000, fractionDigits: 2 }),
        description: faker.commerce.productDescription(),
        category: faker.helpers.arrayElement(categories)._id,
        stock: faker.number.int({ min: 1, max: 100 }),
      });
    }

    console.log('Seeder run successfully!');
    await app.close();
  } catch (error) {
    console.error('Seeder error:', error);
    process.exit(1);
  }
}

bootstrap();
