import { ApiBody, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Category } from './category.schema';

export const CategoriesSwaggerDocs = {
  create: [
    ApiOperation({ summary: 'Create a new category' }),
    ApiBody({ type: Category }),
    ApiResponse({ status: 201, description: 'Category created successfully' })
  ],
  findAll: [
    ApiOperation({ summary: 'Get all categories' }),
    ApiResponse({ status: 200, description: 'List of categories' })
  ]
};
