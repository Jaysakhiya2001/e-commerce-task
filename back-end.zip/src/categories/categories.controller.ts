import { Controller, Get, Post, Body } from '@nestjs/common';
import { CategoriesService } from './categories.service';
import { Category } from './category.schema';

@Controller('categories')
export class CategoriesController {
  constructor(private readonly categoriesService: CategoriesService) {}

  @Post()
  async create(@Body() body: Partial<Category>) {
    return this.categoriesService.create(body);
  }

  @Get()
  async findAll() {
    return this.categoriesService.findAll();
  }
}
